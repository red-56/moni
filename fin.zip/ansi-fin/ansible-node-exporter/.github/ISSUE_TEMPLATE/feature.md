---
name: Feature
about: If you want to propose a new feature or enhancement
labels: enhancement
---

**What is missing?**

**Why do we need it?**

**Environment**

* Role version:

    `Insert release version/galaxy tag or Git SHA here`

* Ansible version information:

    `ansible --version`
    <!-- Replace the command with its output above -->

**Anything else we need to know?**:
